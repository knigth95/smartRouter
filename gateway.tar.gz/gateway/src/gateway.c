#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include "comport.h"
#include "qcloud_iot_export.h"
#include "data_template_client_json.h"
#include "lite-utils.h"

void HandleControlMsgFromCloud(int fd, void *pClient);
void ReportDataToCloud(void *pClient);
void OnReportReplyCallback(void *pClient, Method method, ReplyAck replyAck, const char *pJsonDocument, void *pUserdata);
void HandleDataFromComport(int fd);
static void event_handler(void *pclient, void *handle_context, MQTTEventMsg *msg);
static void ConfigInitParams(TemplateInitParams *initParams);
static void OnControlMsgCallback(void *pClient, const char *pJsonValueBuffer, uint32_t valueLength,
                                 DeviceProperty *pProperty);
static void InitDataTemplate(void);
static int ConfigDataTemplate(void *client);
static void GetStatusReplyAckCb(void *pClient, Method method, ReplyAck replyAck, const char *pReceivedJsonDocument, void *pUserdata);

#define REGION "china"
#define DEVICE_NAME "router1"
#define PRODUCT_ID "JM5OCF82QZ"
#define DEVICE_SECRET "6SYQA4SJvHXpWbMe96KXqw=="
#define BANDRATE 115200
#define COMPORT_NUMBER "/dev/ttyS1"
#define cCHANGED 2
typedef struct _ProductDataDefine {
    TYPE_DEF_TEMPLATE_FLOAT   m_temperature;
    TYPE_DEF_TEMPLATE_FLOAT   m_humidity;
    TYPE_DEF_TEMPLATE_FLOAT   m_illumination;
    TYPE_DEF_TEMPLATE_BOOL    m_door;
    TYPE_DEF_TEMPLATE_BOOL    m_light;
    TYPE_DEF_TEMPLATE_BOOL    m_ac;
    TYPE_DEF_TEMPLATE_FLOAT   m_curtain;

} ProductDataDefine;
static ProductDataDefine productData;

#define TOTAL_PROPERTY_COUNT 7
static sDataPoint dataTemplates[TOTAL_PROPERTY_COUNT];
static MQTTEventType sg_subscribe_event_result = MQTT_EVENT_UNDEF;


static char dataReportBuffer[2048];
static size_t dataReportBufferSize = sizeof(dataReportBuffer)/sizeof(dataReportBuffer[0]);




int main(void)
{
	int fd, rc;	
	ReplyAck ackRequest = ACK_NONE;
	TemplateInitParams initParams = DEFAULT_TEMPLATE_INIT_PARAMS;	

	IOT_Log_Set_Level(eLOG_DEBUG);

	//配置连接参数，连接MQTT云端服务并构造数据模板客户端	
	ConfigInitParams(&initParams);
	void *client = IOT_Template_Construct(&initParams, NULL);
	if (client != NULL) {
        	Log_i("Cloud Device Construct Success");
    	} else {
        	Log_e("Cloud Device Construct Failed");
        	return QCLOUD_ERR_FAILURE;
    	}
	//注册设备数据模板属性
	InitDataTemplate();//初始化属性数据
	rc = ConfigDataTemplate(client);
	if (rc == QCLOUD_RET_SUCCESS) {
		Log_i("Register data template propertys Success");
	} else {
		Log_e("Register data template propertys Failed: %d", rc);
		goto exit;
	}
	
	//从云端读取数据模板属性，可根据需要选择这种方式对属性数值进行初始化；
	//也可直接读取传感器或执行器并更新到云端，此时不需要下面的代码。
	rc = IOT_Template_GetStatus(client, GetStatusReplyAckCb, &ackRequest, QCLOUD_IOT_MQTT_COMMAND_TIMEOUT);
	if (rc != QCLOUD_RET_SUCCESS) {
		Log_e("Get data status fail, err: %d", rc);
	}
	while(ACK_NONE == ackRequest)
	{
		IOT_Template_Yield(client, 200);
	}
	Log_i("%f",productData.m_temperature);
	
	//以非阻塞读和写的方式打开并设置串口
	if((fd = open(COMPORT_NUMBER, O_RDWR | O_NOCTTY | O_NDELAY)) < 0)
	{//打开窗口失败
		printf("Open %s failed\n", COMPORT_NUMBER);
		return 0;
	}
	if(fcntl(fd, F_SETFL, 0) < 0)
	{
		printf("fcntl failed!\n");
		return 0;
	}
	SetComPort(fd, 115200, 8, 'N', 1);//设置成8N1 115200bps
	
	//循环发送数据
	
	while(1)
	{	
		//进行MQTT报文读取，消息处理，超时请求，心跳包及重连状态管理等任务		
		if(!IOT_Template_IsConnected(client))//连接断开，重连
		{
			Log_e("Attemping to reconnect...");			
			rc = IOT_Template_Destroy(client);
			client = IOT_Template_Construct(&initParams, NULL);
			if(client != NULL)
			{
				Log_d("Connected!");
				rc = ConfigDataTemplate(client);
			}		
		}
		IOT_Template_Yield(client, 200);
		
		//对云端下发控制命令进行处理
		HandleControlMsgFromCloud(fd, client);

		//接收串口数据
		HandleDataFromComport(fd);

		//向云端上报数据
		ReportDataToCloud(client);	
		
	}
exit:
	IOT_Template_Destroy(client);
	return 0;
}



void HandleDataFromComport(int fd)
{
	#define MAX_DATA_LENGTH 5
	unsigned int cnt, i;
	unsigned char buf[4096];
	static unsigned char recvData[MAX_DATA_LENGTH], *pData, checkSum, recvFlag = 0, recvLength;
	
	cnt = read(fd, buf, 4096);

	if (cnt == 0)
		return;

	for (i = 0; i < cnt; i++)
	{
	/*从串口缓冲区读出的数据保存在buf中，数据长度为cnt，这里需要你们根据串口通讯协议对buf中的字节进行解析*/
	/*大体思路是连续收到2字节同步码后，接收第3字节指定长度的数据并计算累加校验和，最后将计算和收到的累加校验和进行比较*/
	/*收到正确的1帧后，将收到的数据更新到dataTemplates数组中对应属性的位置，并将state置为eCHANGED，通知ReportDataToCloud函数上报数据*/
	}
}

static void ConfigInitParams(TemplateInitParams *initParams)
{
	/*此处添加连接参数结构体初始化的代码*/
}

static void InitDataTemplate(void)
{
	/*此处添加数据模板属性结构体初始化的代码*/
}

static int ConfigDataTemplate(void *client)
{
	/*此处添加注册数据模板属性的代码*/
}

void ReportDataToCloud(void *pClient)
{
	/*此处添加向云端上报传感器和执行器的代码*/
}	

void OnReportReplyCallback(void *pClient, Method method, ReplyAck replyAck, const char *pJsonDocument, void *pUserdata)
{
	Log_i("Receive report reply(ack=%d): %s", replyAck, pJsonDocument);
}

static void OnControlMsgCallback(void *pClient, const char *pJsonValueBuffer, uint32_t valueLength,
                                 DeviceProperty *pProperty)
{
	/*此处添加收到云端下传指令后回调函数的代码*/
}

void HandleControlMsgFromCloud(int fd, void *pClient)
{
	/*此处添加代码完成对云端下传控制指令的响应*/
}

static void GetStatusReplyAckCb(void *pClient, Method method, ReplyAck replyAck, const char *pReceivedJsonDocument, void *pUserdata)
{
	Request *request = (Request *)pUserdata;
	if (*((ReplyAck *)request->user_context) == ACK_ACCEPTED)
		IOT_Template_ClearControl(pClient, request->client_token, NULL, QCLOUD_IOT_MQTT_COMMAND_TIMEOUT);
	else
		*((ReplyAck *)request->user_context) = replyAck;
	printf("Received Json Document = %s", pReceivedJsonDocument);
	char *data = LITE_json_value_of("data",	pReceivedJsonDocument);
	if (data != NULL)
	{
		char *reported = LITE_json_value_of("reported", data);
		if(reported != NULL)
		{
			if(reported != NULL)
			{
				char *tmpr = LITE_json_value_of("temperature", reported);
				if(tmpr != NULL)
				productData.m_temperature = atof(tmpr);
			}	
		}
	}
}

static void event_handler(void *pclient, void *handle_context, MQTTEventMsg *msg)
{
    uintptr_t packet_id = (uintptr_t)msg->msg;

    switch (msg->event_type) {
        case MQTT_EVENT_UNDEF:
            Log_i("undefined event occur.");
            break;

        case MQTT_EVENT_DISCONNECT:
            Log_i("MQTT disconnect.");
            break;

        case MQTT_EVENT_RECONNECT:
            Log_i("MQTT reconnect.");
            break;

        case MQTT_EVENT_SUBCRIBE_SUCCESS:
            sg_subscribe_event_result = msg->event_type;
            Log_i("subscribe success, packet-id=%u", (unsigned int)packet_id);
            break;

        case MQTT_EVENT_SUBCRIBE_TIMEOUT:
            sg_subscribe_event_result = msg->event_type;
            Log_i("subscribe wait ack timeout, packet-id=%u", (unsigned int)packet_id);
            break;

        case MQTT_EVENT_SUBCRIBE_NACK:
            sg_subscribe_event_result = msg->event_type;
            Log_i("subscribe nack, packet-id=%u", (unsigned int)packet_id);
            break;

        case MQTT_EVENT_PUBLISH_SUCCESS:
            Log_i("publish success, packet-id=%u", (unsigned int)packet_id);
            break;

        case MQTT_EVENT_PUBLISH_TIMEOUT:
            Log_i("publish timeout, packet-id=%u", (unsigned int)packet_id);
            break;

        case MQTT_EVENT_PUBLISH_NACK:
            Log_i("publish nack, packet-id=%u", (unsigned int)packet_id);
            break;
        default:
            Log_i("Should NOT arrive here.");
            break;
    }
}
