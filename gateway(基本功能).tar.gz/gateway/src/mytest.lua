local fs = require "nixio.fs"
m = Map("mytest", translate("测试"), translate("测试页面修改mytest软件包配置中串口发送的消息和发送时间间隔。"))
s = m:section(TypedSection, "mytest", "")
s.addremove = false
s.anonymous = true
view_period = s:option(Value, "period", translate("发送间隔"))
view_period.default = 0
view_output = s:option(TextValue, "output", "消息内容")
view_output.rmempty = false
view_output.rows = 2
m.on_after_commit = function(self)
	luci.sys.call("/etc/init.d/mytest restart > /dev/null")	
end
return m
